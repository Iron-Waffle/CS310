/*
    Student Name: Boris Davis
    File Name: Ch03Exercise7.cpp
    Date: 9/5/2024
*/

#include <iostream>
#include <iomanip>
#include <locale>

using namespace std;

int main()
{
    /* Local variables for the program */

    double net_Balance;
    double payment;
    double d1;
    double d2;
    double interest_Rate;
    double average_Daily_Balance;
    double interest;


    /* Ask for the user's input */

    cout << "Enter the net balance: ";
    cin >> net_Balance;

    cout << "Enter the payment amount: ";
    cin >> payment;

    cout << "Enter the number of days in the billing cycle: ";
    cin >> d1;

    cout << "Enter the number of days payment is made before the billing cycle: ";
    cin >> d2;

    cout << "Enter the interest rate per month using decimals: ";
    cin >> interest_Rate;


    /* Calculate the average daily balance */
    average_Daily_Balance = (net_Balance * d1 - payment * d2) / d1;

    /* Calculate the interest */
    interest = average_Daily_Balance * interest_Rate;

    /* Format the out in two decimal places with the thousands separator */
    cout << fixed << setprecision(2);
    locale loc("");
    cout.imbue(loc);


    /* Displays results */
    cout << "Average Daily Balance: $" << average_Daily_Balance << endl;
    cout << "Interest on the unpaid balance: $" << interest << endl;

    
    return 0;
}
