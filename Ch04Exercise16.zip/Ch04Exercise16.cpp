/*
	Student Name: Boris Davis
	File Name: Ch04Exercise16.cpp
	Date: 9/13/2024

*/

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{

	// The publisher's payment options.
	const double author_Payment_1 = 5000;
	const double author_payment_2 = 20000;
	const double payment_Percentage_2 = 0.125;
	const double payment_Percentage_3 = 0.10;
	const double payment_Percentage_3_2 = 0.14;
	const int payment_Threshold = 4000;


	// This is the price of each novel. 
	double net_Price;

	// This is the estimated amount of novels sold as an integer. 
	int estimated_Copies_Sold;

	// The price of each individual novel. 
	cout << "Enter the net price of each novel: " << endl;
	cin >> net_Price;

	// The estimated number of novels sold. 
	cout << "\nEnter the estimated number of copies sold: " << endl;
	cin >> estimated_Copies_Sold;

	// This line is the payment for publisher option one.
	double payment1 = author_Payment_1 + author_payment_2;

	// This line is the payment for publisher option two. 
	double payment2 = payment_Percentage_2 * net_Price * estimated_Copies_Sold;


	/* These lines indicate the payment for publisher option three.

	The "if" line is used if the estimated copies sold is less than or equal to the payment threshold.
	The "else" line is used if the estimated copies sold is greater than the payment threshold. */
	double payment3 = 0;
	if (estimated_Copies_Sold <= payment_Threshold)
		payment3 = payment_Percentage_3 * net_Price * estimated_Copies_Sold;
	else
		payment3 = payment_Percentage_3 * net_Price * payment_Threshold + payment_Percentage_3_2 *
		net_Price * estimated_Copies_Sold - payment_Threshold;


	// Outputs the payment based on publisher payment option.
	cout << fixed << setprecision(2);
	cout << "\nPayment if choosing option 1: $" << payment1 << endl;
	cout << "Payment if choosing option 2: $" << payment2 << endl;
	cout << "Payment if choosing option 3: $" << payment3 << endl;


	// Outputs the best publisher payment option.
	if (payment1 > payment2 && payment1 > payment3)
		cout << "\nThe best choice is choice 1." << endl;
	else if (payment2 > payment1 && payment2 > payment3)
		cout << "\nThe best option is choice 2." << endl;
	else
		cout << "\nThe best option is choice 3." << endl;

	// Closing message.
	cout << "\nPress any key to continue..." << endl;

	return 0;
}
