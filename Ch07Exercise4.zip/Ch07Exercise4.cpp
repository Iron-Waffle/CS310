/*
	Student Name: Boris Davis
	File Name: Ch07Exercise4.cpp
	Date: 10/4/2024
*/

#include <iostream>
#include <string>

using namespace std;


bool isVowel(char ch) // Function for checking if a character is a vowel.
{
	switch (ch) // Uses a switch statement to check for the value of ch.
	{
	case 'A': // Checks for an uppercase 'A'.
	case 'E':
	case 'I':
	case 'O':
	case 'U':
	case 'Y':
	case 'a': // Checks for a lowercase 'a'.
	case 'e':
	case 'i':
	case 'o':
	case 'u':
	case 'y':
		return true; // True if ch is a vowel.
	default:
		return false; // False if ch is not a vowel.
	}
}

string vowel_Eradicator(const string& input) // Function to remove vowels from the input.
{
	string result; // Initializes to store the result without vowels.
	for (char ch : input) //Loops through each character in the input string.
	{
		if (!isVowel(ch)) // Checks if the character is a vowel.
		{
			result = result + ch; // Adds the non-vowel characters to the result.
		}
	}
	return result; // Returns the string without the vowels.
}

int main()
{
	cout << "==============================================" << endl;
	cout << "=====| Welcome to The Vowel Eradicator! |=====" << endl;
	cout << "==============================================" << endl;


	string str; // String input variable.
	char choice; // Character variable to ask whether or not to continue.

	do
	{
		do // For input validation purposes.
		{
			cout << "\nEnter string: " << endl;

			getline(cin, str); // Allows the entire line to be read.
			if (str.empty()) // Checks whether the input field is empty.
			{
				cout << "\nInvalid input. Please only enter a string: " << endl;
			}

		} while (str.empty()); // Loops until a valid string input is detected.


		str = vowel_Eradicator(str); /* This takes the string input from earlier, removes the vowels
										and stores the non-vowel str for later use. */

		// Outputs the previous string input with the vowels removed.
		cout << "\n\nBased on the input, the string after removing all vowels results in: " << str << endl;

		// Asks the user if they would like to enter another string or exit the program.
		cout << "\n\nDo you want to enter another string? (type y/n): " << endl;
		cin >> choice;
		cin.ignore(); // Clears the \n or newline character.

	} while (choice == 'y' || choice == 'Y'); // If the variable choice is 'y' or 'Y', the loop continues to execute.

	// closing message for non-Visual Studio IDEs.
	cout << "\nPress any key to continue..." << endl;

	// Exits the code.
	return 0;
}